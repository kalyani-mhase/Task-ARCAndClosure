//
//  ContactTableViewCell.swift
//  ContactScreen
//
//  Created by Admin on 19/01/22.
//

import UIKit

class ContactTableViewCell: UITableViewCell {

    @IBOutlet weak var view1: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
}
