//
//  NextTableViewCell.swift
//  ContactScreen
//
//  Created by Admin on 19/01/22.
//

import UIKit

class NextTableViewCell: UITableViewCell {

    @IBOutlet weak var view2: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
